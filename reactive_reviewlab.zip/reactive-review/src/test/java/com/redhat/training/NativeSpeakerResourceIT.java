package com.redhat.training;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeSpeakerResourceIT extends SpeakerResourceTest {

    // Execute the same tests but in native mode.
}
