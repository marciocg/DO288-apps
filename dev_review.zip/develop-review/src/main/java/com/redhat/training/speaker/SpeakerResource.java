package com.redhat.training.speaker;

import io.quarkus.panache.common.Sort;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.headers.Header;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.jboss.resteasy.annotations.Query;

import javax.print.attribute.standard.PagesPerMinute;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.net.URI;
import java.util.List;
import java.util.ArrayList;

@Path("/speakers")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class SpeakerResource {


    @GET
    @Operation(
        summary = "Retrives the list of speakers",
        description = "GET com listAll na entidade"
    )
    @APIResponse(
        responseCode = "200",
        description = "sucesso lista de Speaker"
    )
    public List<Speaker> getSpeakers(
        @DefaultValue("id") @QueryParam("sortBy") String sortBy,
        @DefaultValue("0") @QueryParam("pageIndex") int pageIndex,
        @DefaultValue("25") @QueryParam("pageSize") int pageSize

    ) {
        return Speaker.findAll(
            Sort.by(filterSortBy(sortBy))
        ).page(pageIndex, pageSize)
        .list();
        
    }

    @POST
    @Transactional
    @Operation(
        summary = "Adds a speaker",
        description = "recebe novo speaker e um uriinfo?"
    )
    @APIResponse(
        responseCode = "201",
        headers = {
            @Header(
                name = "id",
                description = "ID of entity",
                schema = @Schema(implementation = Integer.class)
            ),
            @Header(
                name = "location",
                description = "URI of entity",
                schema = @Schema(implementation = String.class)
            )
        },
        description = "Entity succesfully created"
    )
    public Response createSpeaker(Speaker newSpeaker, @Context UriInfo uriInfo) {
        newSpeaker.persist();

        return Response.created(generateUriForSpeaker(newSpeaker, uriInfo))
            .header("id", newSpeaker.id)
            .build();
    }

    private URI generateUriForSpeaker(Speaker speaker, UriInfo uriInfo) {
        return uriInfo.getAbsolutePathBuilder().path("/{id}").build(speaker.id);
    }

    private String filterSortBy(String sortBy) {
        if (!sortBy.equals("id") && !sortBy.equals("name")){
            return "id";
        }

        return sortBy;
    }

    @DELETE
    @Transactional
    @Path("{id}")
    public void deleteSpeaker(@PathParam("id") Long id) {
        if (!Speaker.deleteById(id)) {
            throw new NotFoundException();
        }
    }
}
