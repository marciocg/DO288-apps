package com.redhat.training.speaker;

import javax.persistence.Entity;

import io.quarkus.hibernate.orm.panache.PanacheEntity;

@Entity
public class Talk extends PanacheEntity {
     public String title;
     public int duration;

}
