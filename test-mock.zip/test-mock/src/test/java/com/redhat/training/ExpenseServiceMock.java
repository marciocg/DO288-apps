package com.redhat.training;

import java.util.UUID;

import javax.enterprise.context.ApplicationScoped;

import com.redhat.training.expense.CrudTest;
import com.redhat.training.expense.ExpenseService;

import io.quarkus.test.Mock;
import io.quarkus.test.junit.QuarkusTest;

@Mock
@ApplicationScoped
public class ExpenseServiceMock extends ExpenseService {
    @Override
    public boolean exists(UUID uuid) {
        //return true;
        return !uuid.equals(UUID.fromString(CrudTest.NON_EXISTING_UUID));
    }
}
